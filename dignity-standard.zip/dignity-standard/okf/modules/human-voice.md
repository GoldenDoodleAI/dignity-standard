---
type: module
title: Human voice standards (optional)
description: Optional module that suppresses common AI writing patterns. Not part of the dignity or trauma-informed rules; adopt if you want output that reads as written by a person.
tags: [module, style, ai-patterns, optional]
---

# Human voice standards

This module is optional and separate from the standard. It reflects GoldenDoodle AI's house style for suppressing writing patterns that read as machine-generated. Organizations may adopt it, adapt it, or ignore it.

## Vocabulary

Do not use: delve, tapestry, landscape (as metaphor), realm, beacon, leverage (as a verb), harness (as a verb), foster, robust, pivotal, transformative, groundbreaking, cutting-edge, multifaceted, intricate, cornerstone, paramount, navigate (as metaphor), illuminate, nuanced, unprecedented, game-changing, revolutionary.

## Punctuation

No em dashes. Do not substitute parentheses as a workaround. Use a comma, a period, or restructure.

## Structure

- Vary paragraph length. One sentence is fine. So is eight.
- Do not use "It's not X, it's Y" framing.
- Do not open with "In today's [adjective] world" or any variant.
- Do not end with a paragraph that restates the body.
- Break the rule-of-three habit. Two or four items are fine.
- Minimize "Furthermore," "Moreover," "Additionally."

## Tone

- Use contractions.
- Mix sentence rhythm.
- Take positions where the content calls for them. False balance reads as evasion.

## Specifics

- Never fabricate statistics, citations, or quotes. If real data is not available, say so.
- No "studies show" or "experts agree" without a named, verifiable source.
- Flag speculation as speculation.

## Enthusiasm and hedging

- Do not call something "exciting" or "remarkable" without a concrete reason attached.
- One qualifier per claim, maximum, and only when the uncertainty is real.

## Maintenance

Model fingerprints change with each release. This list is dated to the current release of the standard and is expected to be revised. Contributions of newly observed patterns are welcome; include the model and version where the pattern was observed.
